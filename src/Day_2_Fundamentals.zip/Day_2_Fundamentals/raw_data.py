# Hardcoded variables
item_name = "Laptop"      # String
quantity = 2              # Integer
price = 499.99            # Float
in_stock = True            # Boolean

print("Item:", item_name, ", Qty:", quantity, ", Price:", price, ", Available:", in_stock)

total_cost = quantity * price

print("Total Cost:", total_cost)