name = input("Enter your name: ")
age = int(input("Enter your current age: "))
print(f"Hey {name}, you will be {age + 4} years old in 2030!")