name = input("Enter your name: ")
print(f"Welcome, {name}!")
