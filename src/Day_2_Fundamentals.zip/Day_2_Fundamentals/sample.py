age=20;
height=5.9;
name="John Doe";
is_student=True;
print("Name:",name);
print("Age:",age);
print("Height:",height);
print("Is Student:",is_student);